準備6種類型模型 : DNN、RNN、CNN、VGG、Resnet v1、Resnet v2
準備3種維度的data shape以配合各種類型模型 : for 1-V / 2 for 2-V / 3 for 3-V
準備1種資料增強方式，可選擇開啟或關閉 : ImageDataGenerator_threshold & fit_generator
準備1種callback，以選擇最佳模型 : checkpoint
準備1套自動記錄模型效果之function : Record Score

------------------------------- 備註 ------------------------------- 
# 考慮壓縮檔案大小，資料集尚需自行下載
# 參數需調整位置包含 : (1)Prepare data、(2)Define Parameters

------------------------------- mnist 選用結果 ------------------------------- 
Model4 : VGG 
Epochs : 60
Best Val score    : 0.9935
Best epochs    : 59
accuracy    : 0.9952
precision   : 0.9952
recall      : 0.9952
f1-score    : 0.9952

# CNN、VGG 模型效果較佳
# 在上述模型中關閉 ImageDataGenerator_threshold 訓練效果較佳
# 60 epochs 於59時，validation 效果最佳，故推測 epoch 上限提高還有可能效果更佳 

------------------------------- cifar 選用結果 ------------------------------- 
Model6.1 : ResNet v2 
Epochs : 50
Best Val score    : 0.8487
Best epochs    : 44
accuracy    : 0.8432
precision   : 0.8555
recall      : 0.8432
f1-score    : 0.8441

# VGG、ResNet 模型效果較佳
# 在上述模型中開啟 ImageDataGenerator_threshold 訓練效果較佳
# 50 epochs 於44時，validation 效果最佳，故推測 epoch 上限提高還有可能效果更佳